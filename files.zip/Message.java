package com.example.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.expression.common.TemplateParserContext;
import org.springframework.expression.spel.standard.SpelExpressionParser;

import java.util.Objects;
import java.util.UUID;

@Getter
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class Message {

    private String id;
    private String code;
    private String title;
    private String detail;

    // ----------------------------------------------------------------
    // Package-private constructors
    // ----------------------------------------------------------------

    Message(String code, String title, String detail) {
        Objects.requireNonNull(code, "message code cannot be null");
        Objects.requireNonNull(title, "message title cannot be null");
        this.id = UUID.randomUUID().toString();
        this.code = code;
        this.title = title;
        this.detail = detail;
    }

    Message(String id, String code, String title, String detail) {
        Objects.requireNonNull(code, "message code cannot be null");
        Objects.requireNonNull(title, "message title cannot be null");
        this.id = id;
        this.code = code;
        this.title = title;
        this.detail = detail;
    }

    // ----------------------------------------------------------------
    // Static factory methods
    // ----------------------------------------------------------------

    public static Message create(String code, String title) {
        return new Message(code, title, null);
    }

    public static Message create(String code, String title, String detail) {
        return new Message(code, title, detail);
    }

    public static Message create(String id, String code, String title, String detail) {
        return new Message(id, code, title, detail);
    }

    // ----------------------------------------------------------------
    // Instance methods
    // ----------------------------------------------------------------

    public Message formatTitle(Object... arguments) {
        return new Message(this.code, evalExp(this.title, arguments), this.detail);
    }

    public Message formatDetail(Object... arguments) {
        return new Message(this.code, this.title, evalExp(this.detail, arguments));
    }

    public Message withDetail(String detail) {
        return new Message(this.code, this.title, detail);
    }

    // ----------------------------------------------------------------
    // SpEL expression evaluator (replaces SpelExpUtils.evalExp)
    // ----------------------------------------------------------------

    private static String evalExp(String template, Object... args) {
        if (template == null) return null;
        try {
            SpelExpressionParser parser = new SpelExpressionParser();
            // Simple indexed placeholder replacement: {0}, {1}, ...
            String result = template;
            for (int i = 0; i < args.length; i++) {
                result = result.replace("{" + i + "}", args[i] == null ? "" : args[i].toString());
            }
            return result;
        } catch (Exception e) {
            return template;
        }
    }

    // ----------------------------------------------------------------
    // toString
    // ----------------------------------------------------------------

    @Override
    public String toString() {
        return "Message [id=" + id + ", code=" + code + ", title=" + title + ", detail=" + detail + "]";
    }
}
