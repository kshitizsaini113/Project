package com.example.response;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Collection;

@Slf4j                                             // replaces manual LOGGER declaration
public class ResponseAssembler implements ResponseSuccessAssembler, ResponseErrorAssembler {

    private final RestResponse restResponseToAssemble;

    // ----------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------

    protected ResponseAssembler(RestResponse restResponse) {
        log.debug("Creating Response Assembler Object from Response.");
        log.trace("Response is = [{}]", restResponse);
        this.restResponseToAssemble = restResponse;
    }

    // ----------------------------------------------------------------
    // Static factory methods
    // ----------------------------------------------------------------

    public static ResponseAssembler assemble() {
        log.debug("Creating ResponseAssembler with empty Response object.");
        return new ResponseAssembler(new RestResponse());
    }

    public static ResponseAssembler empty(HttpStatus status) {
        log.debug("Creating Response with HttpStatus status.");
        if (status == null) {
            throw new IllegalArgumentException("HttpStatus cannot be null.");
        }
        RestResponse restResponse = new RestResponse();
        restResponse.setHttpStatus(status);
        return new ResponseAssembler(restResponse);
    }

    public static ResponseAssembler empty(ResponseHttpStatus status) {
        log.debug("Creating Response with ResponseHttpStatus status.");
        if (status == null) {
            throw new IllegalArgumentException("ResponseHttpStatus cannot be null.");
        }
        RestResponse restResponse = new RestResponse();
        restResponse.setHttpStatus(status.getStatus());
        return new ResponseAssembler(restResponse);
    }

    // ----------------------------------------------------------------
    // addMetadata
    // ----------------------------------------------------------------

    public ResponseAssembler addMetadata(MetaData meta) {
        log.debug("Adding metadata to the Response. Total messages in metadata are : [{}].", meta.asMap().size());
        log.trace("Metadata messages : {}", meta);
        if (this.restResponseToAssemble.meta == null) {
            this.restResponseToAssemble.setMeta(meta);
        } else {
            this.restResponseToAssemble.meta.merge(meta);
        }
        return this;
    }

    // ----------------------------------------------------------------
    // setHeader
    // ----------------------------------------------------------------

    public ResponseAssembler setHeader(String key, String value) {
        log.debug("Adding header in the response. header name =[{}].", key);
        log.trace("Adding header in the response. header name =[{}], value =[{}].", key, value);
        this.restResponseToAssemble.headers.add(key, value);
        return this;
    }

    // ----------------------------------------------------------------
    // addErrorMessage — now accepts Message instead of String
    // ----------------------------------------------------------------

    @Override
    public ResponseAssembler addErrorMessage(Message message) {
        log.debug("Adding error message in the response. message : [{}]", message);
        if (this.restResponseToAssemble.errors == null) {
            this.restResponseToAssemble.setErrors(new ArrayList<>());
        }
        this.restResponseToAssemble.errors.add(message);
        return this;
    }

    @Override
    public ResponseAssembler addErrorMessages(Collection<Message> messages) {
        log.debug("Adding error messages in the response. messages : [{}]", messages);
        if (messages == null) {
            return this;
        }
        messages.forEach(m -> {
            if (m != null) {
                log.trace("Adding error message in the response. message : [{}]", m);
                this.addErrorMessage(m);
            }
        });
        return this;
    }

    // ----------------------------------------------------------------
    // build
    // ----------------------------------------------------------------

    public RestResponse build(Object data) {
        log.debug("Building Response with data and default response status :[{}]", HttpStatus.OK);
        this.restResponseToAssemble.setData(data);
        this.restResponseToAssemble.setHttpStatus(HttpStatus.OK);
        return this.build();
    }

    public RestResponse build(ResponseHttpStatus errorStatus, Object payload) {
        log.debug("Building Response with data and response status :[{}]", errorStatus);
        this.restResponseToAssemble.setHttpStatus(errorStatus.getStatus());
        this.restResponseToAssemble.setData(payload);
        return this.build();
    }

    public RestResponse build() {
        log.debug("Building final Response.");
        log.debug("Building Response with response status :[{}]", this.restResponseToAssemble.httpStatus);
        if (this.restResponseToAssemble.httpStatus == null) {
            throw new IllegalStateException("Cannot build a response without http status code");
        }
        return this.restResponseToAssemble;
    }
}
