package com.example.response;

// =====================================================================
// Response.java
// =====================================================================

public interface Response {}


// =====================================================================
// ResponseSuccessAssembler.java
// =====================================================================

/*
public interface ResponseSuccessAssembler {
    ResponseAssembler addMetadata(MetaData meta);
    ResponseAssembler setHeader(String key, String value);
    RestResponse build(Object data);
    RestResponse build();
}
*/


// =====================================================================
// ResponseErrorAssembler.java  — updated to use Message
// =====================================================================

/*
import java.util.Collection;

public interface ResponseErrorAssembler {
    ResponseAssembler addErrorMessage(Message message);           // was String
    ResponseAssembler addErrorMessages(Collection<Message> messages); // was Collection<String>
    RestResponse build(ResponseHttpStatus errorStatus, Object payload);
}
*/


// =====================================================================
// ResponseHttpStatus.java
// =====================================================================

/*
import org.springframework.http.HttpStatus;

public enum ResponseHttpStatus {
    OK(HttpStatus.OK),
    CREATED(HttpStatus.CREATED),
    BAD_REQUEST(HttpStatus.BAD_REQUEST),
    NOT_FOUND(HttpStatus.NOT_FOUND),
    UNAUTHORIZED(HttpStatus.UNAUTHORIZED),
    FORBIDDEN(HttpStatus.FORBIDDEN),
    INTERNAL_SERVER_ERROR(HttpStatus.INTERNAL_SERVER_ERROR);

    private final HttpStatus status;

    ResponseHttpStatus(HttpStatus status) { this.status = status; }

    public HttpStatus getStatus() { return status; }
}
*/


// =====================================================================
// MetaData.java
// =====================================================================

/*
import lombok.ToString;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

@ToString
public class MetaData {

    private final Map<String, Object> metaMap = new HashMap<>();

    public MetaData add(String key, Object value) {
        this.metaMap.put(key, value);
        return this;
    }

    public MetaData merge(MetaData other) {
        this.metaMap.putAll(other.metaMap);
        return this;
    }

    public Map<String, Object> asMap() {
        return Collections.unmodifiableMap(metaMap);
    }
}
*/
