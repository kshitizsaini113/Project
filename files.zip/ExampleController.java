package com.example.controller;

import com.example.response.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ExampleController {

    // ----------------------------------------------------------------
    // Success — data only
    // ----------------------------------------------------------------
    @GetMapping("/users/{id}")
    public ResponseEntity<RestResponse> getUser(@PathVariable Long id) {
        UserDto user = userService.findById(id);

        RestResponse response = ResponseAssembler
                .assemble()
                .build(user);

        return ResponseEntity.status(response.getHttpStatus()).body(response);
    }

    // ----------------------------------------------------------------
    // Success — with metadata
    // ----------------------------------------------------------------
    @GetMapping("/users")
    public ResponseEntity<RestResponse> listUsers() {
        List<UserDto> users = userService.findAll();

        MetaData meta = new MetaData()
                .add("total", users.size())
                .add("page", 1);

        RestResponse response = ResponseAssembler
                .assemble()
                .addMetadata(meta)
                .build(users);

        return ResponseEntity.status(response.getHttpStatus()).body(response);
    }

    // ----------------------------------------------------------------
    // Error — single Message (richer than plain String: has code + title + detail)
    // ----------------------------------------------------------------
    @PostMapping("/users")
    public ResponseEntity<RestResponse> createUser(@RequestBody UserDto dto) {
        try {
            UserDto created = userService.create(dto);
            RestResponse response = ResponseAssembler.assemble().build(created);
            return ResponseEntity.status(response.getHttpStatus()).body(response);

        } catch (ValidationException ex) {
            // Message.create(code, title, detail) — structured error info
            Message error = Message.create("USR_001", "Validation Failed", ex.getMessage());

            RestResponse response = ResponseAssembler
                    .assemble()
                    .addErrorMessage(error)
                    .build(ResponseHttpStatus.BAD_REQUEST, null);

            return ResponseEntity.status(response.getHttpStatus()).body(response);
        }
    }

    // ----------------------------------------------------------------
    // Error — multiple Messages with dynamic detail via formatDetail()
    // ----------------------------------------------------------------
    @PutMapping("/users/{id}")
    public ResponseEntity<RestResponse> updateUser(@PathVariable Long id, @RequestBody UserDto dto) {

        // Define message templates (typically as constants in a Messages class)
        Message nameRequired  = Message.create("USR_002", "Name is required");
        Message emailInvalid  = Message.create("USR_003", "Email {0} is not valid");

        List<Message> validationErrors = List.of(
                nameRequired,
                emailInvalid.formatDetail(dto.getEmail())  // dynamic placeholder filled in
        );

        if (!validationErrors.isEmpty()) {
            RestResponse response = ResponseAssembler
                    .assemble()
                    .addErrorMessages(validationErrors)
                    .build(ResponseHttpStatus.BAD_REQUEST, null);

            return ResponseEntity.status(response.getHttpStatus()).body(response);
        }

        UserDto updated = userService.update(id, dto);
        RestResponse response = ResponseAssembler.assemble().build(updated);
        return ResponseEntity.status(response.getHttpStatus()).body(response);
    }
}

/*
Example JSON responses:

SUCCESS:
{
  "data": { "id": 1, "name": "Alice" },
  "meta": { "total": 1, "page": 1 }
}

ERROR (List<Message> instead of List<String>):
{
  "errors": [
    { "id": "d3f1a...", "code": "USR_002", "title": "Name is required" },
    { "id": "9c2b4...", "code": "USR_003", "title": "Email", "detail": "foo@bad is not valid" }
  ]
}
*/
