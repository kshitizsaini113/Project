package com.example.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Collections;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@NoArgsConstructor(access = AccessLevel.PACKAGE)  // only ResponseAssembler can instantiate
public final class RestResponse implements Response {

    private static final Logger LOGGER = LoggerFactory.getLogger(RestResponse.class);

    // Lombok @Setter(AccessLevel.PACKAGE) lets ResponseAssembler set fields directly
    // without exposing public setters, keeping the class effectively immutable from outside.

    @Setter(AccessLevel.PACKAGE)
    Object data;

    @Setter(AccessLevel.PACKAGE)
    MetaData meta;

    @Setter(AccessLevel.PACKAGE)
    @JsonIgnore
    HttpStatus httpStatus;

    @Setter(AccessLevel.PACKAGE)
    List<Message> errors;                          // <-- changed from List<String>

    @Setter(AccessLevel.PACKAGE)
    @JsonIgnore
    MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

    // ----------------------------------------------------------------
    // getData — type-safe retrieval via Jackson
    // ----------------------------------------------------------------

    @JsonInclude(JsonInclude.Include.ALWAYS)
    public <T> T getData(Class<T> type) {
        if (this.data == null) {
            return null;
        }
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(this.data, type);
        } catch (Exception e) {
            LOGGER.debug("Could not convert Response.data (Payload) to data type = [{}]",
                    new Object[]{type.getName(), e});
            return null;
        }
    }

    @JsonInclude(JsonInclude.Include.ALWAYS)
    public <T> T getData(TypeReference<T> type) {
        if (this.data == null) {
            return null;
        }
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.convertValue(this.data, type);
        } catch (Exception e) {
            LOGGER.debug("Could not convert Response.data (Payload) to data type = [{}]",
                    new Object[]{type.getType().getTypeName(), e});
            return null;
        }
    }

    // ----------------------------------------------------------------
    // Public read accessors
    // ----------------------------------------------------------------

    public Object getData() {
        return data;
    }

    public MetaData getMeta() {
        return meta;
    }

    public List<Message> getErrors() {
        LOGGER.debug("Retrieving errors from Response.");
        if (this.errors == null) {
            LOGGER.debug("Response.error is null.");
            return null;
        }
        LOGGER.debug("No of errors are : [{}]", this.errors.size());
        LOGGER.trace("Response.error details : [{}]", new Object[]{this.errors});
        return Collections.unmodifiableList(this.errors);
    }

    @JsonIgnore
    public HttpStatus getHttpStatus() {
        LOGGER.debug("Retrieving HttpStatus()");
        return this.httpStatus;
    }

    @JsonIgnore
    public MultiValueMap<String, String> getHeaders() {
        LOGGER.debug("Retrieving headers from Response.");
        if (this.headers == null) {
            LOGGER.debug("Response.headers is null.");
            return null;
        }
        LOGGER.debug("No of headers are : [{}]", this.headers.size());
        LOGGER.debug("Response.headers details : [{}]", new Object[]{this.headers});
        return Collections.unmodifiableMap(this.headers);
    }

    // ----------------------------------------------------------------
    // toString
    // ----------------------------------------------------------------

    @Override
    public String toString() {
        return "RestResponse{data=" + data + ", meta=" + meta
                + ", httpStatus=" + httpStatus + ", errors=" + errors + "}";
    }
}
